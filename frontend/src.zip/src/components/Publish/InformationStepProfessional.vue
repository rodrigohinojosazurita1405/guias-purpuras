<!-- 
  ==========================================
  PUBLISHVIEW.VUE - VERSIÓN FINAL
  ==========================================
  
  Actualizado con MenuStep para categoría Gastronomía.
  
  Pasos:
    1. Categoría
    2. Información (específica según categoría)
    3. Imágenes
    4. Menú (SOLO para Gastronomía) ← NUEVO
    5. Plan
    6. Confirmar
-->

<template>
  <MainLayout>
    <section class="publish-section">
      <div class="container">
        <!-- HEADER -->
        <div class="publish-header">
          <h1 class="publish-title">Publica tu Anuncio</h1>
          <p class="publish-subtitle">
            Completa el formulario y llega a miles de personas en Bolivia
          </p>
        </div>

        <!-- INDICADOR DE PASOS -->
        <PublishSteps 
          :current-step="currentStep" 
          :steps="getStepsForCategory()" 
        />

        <!-- FORMULARIO PRINCIPAL -->
        <div class="form-card">
          <!-- PASO 1: Categoría y Ubicación -->
          <CategoryStep
            v-if="currentStep === 1"
            ref="categoryStepRef"
            v-model="formData"
          />

          <!-- PASO 2: Información del Anuncio -->
          <InformationStepProfessional
            v-if="currentStep === 2 && formData.category === 'profesionales'"
            ref="informationStepRef"
            v-model="formData"
            :subcategory="formData.subcategory"
          />
          
          <InformationStepGastronomia
            v-else-if="currentStep === 2 && formData.category === 'gastronomia'"
            ref="informationStepRef"
            v-model="formData"
            :subcategory="formData.subcategory"
          />
          
          <InformationStep
            v-else-if="currentStep === 2"
            ref="informationStepRef"
            v-model="formData"
          />

          <!-- PASO 3: Imágenes -->
          <ImagesStep
            v-if="currentStep === 3"
            ref="imagesStepRef"
            v-model="formData.images"
            :plan="formData.plan"
          />

          <!-- PASO 4: Menú (SOLO GASTRONOMÍA) -->
          <MenuStep
            v-if="currentStep === 4 && formData.category === 'gastronomia'"
            ref="menuStepRef"
            v-model="formData.menuItems"
          />

          <!-- PASO 4/5: Selección de Plan -->
          <PlanStep
            v-if="currentStep === getPlanStepNumber()"
            ref="planStepRef"
            v-model="formData.plan"
          />

          <!-- PASO 5/6: Resumen y Confirmación -->
          <div v-if="currentStep === getSummaryStepNumber()" class="summary-step">
            <SummaryCard 
              :form-data="formData"
              :editable="true"
              @edit-step="goToStep"
            />
          </div>

          <!-- NAVEGACIÓN ENTRE PASOS -->
          <div class="form-navigation">
            <!-- Botón Anterior -->
            <va-button
              v-if="currentStep > 1"
              @click="previousStep"
              color="secondary"
              size="large"
              class="nav-btn"
            >
              <va-icon name="arrow_back" />
              Anterior
            </va-button>

            <!-- Espaciador -->
            <div class="spacer"></div>

            <!-- Botón Siguiente -->
            <va-button
              v-if="currentStep < getTotalSteps()"
              @click="nextStep"
              color="purple"
              size="large"
              class="nav-btn"
              :disabled="isSubmitting"
            >
              Siguiente
              <va-icon name="arrow_forward" />
            </va-button>

            <!-- Botón Publicar -->
            <va-button
              v-if="currentStep === getTotalSteps()"
              @click="submitForm"
              color="yellow-primary"
              size="large"
              class="nav-btn submit-btn"
              :loading="isSubmitting"
            >
              <va-icon name="check_circle" />
              {{ formData.plan === 'free' ? 'Publicar Gratis' : 'Ir al Pago' }}
            </va-button>
          </div>
        </div>

        <!-- INDICADOR DE GUARDADO AUTOMÁTICO -->
        <div v-if="showAutoSaveIndicator" class="auto-save-indicator">
          <va-icon name="cloud_done" color="success" />
          <span>Borrador guardado automáticamente</span>
        </div>
      </div>
    </section>
  </MainLayout>
</template>

<script setup>
// ==========================================
// IMPORTS
// ==========================================
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import MainLayout from '@/components/Layout/MainLayout.vue'
import PublishSteps from '@/components/Publish/PublishSteps.vue'
import CategoryStep from '@/components/Publish/CategoryStep.vue'
import InformationStep from '@/components/Publish/InformationStep.vue'
import InformationStepProfessional from '@/components/Publish/InformationStepProfessional.vue'
import InformationStepGastronomia from '@/components/Publish/InformationStepGastronomia.vue'
import ImagesStep from '@/components/Publish/ImagesStep.vue'
import MenuStep from '@/components/Publish/MenuStep.vue'
import PlanStep from '@/components/Publish/PlanStep.vue'
import SummaryCard from '@/components/Publish/SummaryCard.vue'

// ==========================================
// COMPOSABLES
// ==========================================
const router = useRouter()

// ==========================================
// STATE
// ==========================================
const currentStep = ref(1)
const isSubmitting = ref(false)
const showAutoSaveIndicator = ref(false)

// Referencias a los componentes de cada paso
const categoryStepRef = ref(null)
const informationStepRef = ref(null)
const imagesStepRef = ref(null)
const menuStepRef = ref(null)
const planStepRef = ref(null)

// Datos del formulario (modelo principal)
const formData = ref({
  // Paso 1: Categoría y Ubicación
  category: '',
  subcategory: '',
  city: '',
  address: '',
  
  // Paso 2: Información (varía según categoría)
  title: '',
  description: '',
  
  // Campos comunes
  price: null,
  whatsapp: '',
  email: '',
  website: '',
  
  // Campos específicos para PROFESIONALES
  professionalTitle: '',
  yearsExperience: '',
  university: '',
  graduationYear: null,
  degree: '',
  certifications: '',
  specialties: [],
  services: '',
  successCases: '',
  schedule: '',
  languages: [],
  
  // Campos específicos para GASTRONOMÍA
  priceRange: '',
  deliveryAvailable: false,
  capacity: null,
  parking: false,
  features: [],
  menuItems: [], // ← NUEVO: Array de platos con fotos
  
  // Paso 3: Imágenes (del negocio/logo)
  images: [],
  
  // Paso 4/5: Plan
  plan: 'free'
})

// ==========================================
// COMPUTED - Pasos dinámicos según categoría
// ==========================================

/**
 * Obtiene los nombres de pasos según la categoría
 */
const getStepsForCategory = () => {
  if (formData.value.category === 'gastronomia') {
    return ['Categoría', 'Información', 'Imágenes', 'Menú', 'Plan', 'Confirmar']
  }
  return ['Categoría', 'Información', 'Imágenes', 'Plan', 'Confirmar']
}

/**
 * Obtiene el número de paso donde está PlanStep
 */
const getPlanStepNumber = () => {
  return formData.value.category === 'gastronomia' ? 5 : 4
}

/**
 * Obtiene el número de paso donde está el resumen
 */
const getSummaryStepNumber = () => {
  return formData.value.category === 'gastronomia' ? 6 : 5
}

/**
 * Obtiene el total de pasos
 */
const getTotalSteps = () => {
  return formData.value.category === 'gastronomia' ? 6 : 5
}

// ==========================================
// MÉTODOS DE NAVEGACIÓN
// ==========================================

/**
 * Avanza al siguiente paso
 */
const nextStep = async () => {
  const isValid = await validateCurrentStep()
  
  if (!isValid) {
    console.error('Validación fallida. Revisa los campos obligatorios.')
    return
  }
  
  // Para gastronomía, saltar paso de menú si no es gastronomía
  if (currentStep.value === 3 && formData.value.category !== 'gastronomia') {
    currentStep.value = 4 // Ir directo a Plan
  } else {
    currentStep.value++
  }
  
  scrollToTop()
}

/**
 * Retrocede al paso anterior
 */
const previousStep = () => {
  if (currentStep.value > 1) {
    // Para gastronomía, ajustar navegación hacia atrás
    if (currentStep.value === 5 && formData.value.category !== 'gastronomia') {
      currentStep.value = 3 // Saltar MenuStep al regresar
    } else {
      currentStep.value--
    }
    scrollToTop()
  }
}

/**
 * Ir a un paso específico
 */
const goToStep = (step) => {
  currentStep.value = step
  scrollToTop()
}

/**
 * Scroll suave al inicio
 */
const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

// ==========================================
// VALIDACIONES
// ==========================================

/**
 * Valida el paso actual
 */
const validateCurrentStep = async () => {
  let stepRef = null
  
  switch (currentStep.value) {
    case 1:
      stepRef = categoryStepRef.value
      break
    case 2:
      stepRef = informationStepRef.value
      break
    case 3:
      stepRef = imagesStepRef.value
      break
    case 4:
      // Para gastronomía es MenuStep, para otros es PlanStep
      if (formData.value.category === 'gastronomia') {
        stepRef = menuStepRef.value
      } else {
        stepRef = planStepRef.value
      }
      break
    case 5:
      // Para gastronomía es PlanStep, para otros es resumen (no requiere validación)
      if (formData.value.category === 'gastronomia') {
        stepRef = planStepRef.value
      } else {
        return true // Resumen no requiere validación
      }
      break
    case 6:
      // Solo para gastronomía (resumen)
      return true
    default:
      return true
  }
  
  if (stepRef && typeof stepRef.validate === 'function') {
    return stepRef.validate()
  }
  
  return true
}

// ==========================================
// AUTO-GUARDADO DE BORRADOR
// ==========================================

const saveAsDraft = () => {
  try {
    const draft = {
      ...formData.value,
      savedAt: new Date().toISOString()
    }
    localStorage.setItem('listing_draft', JSON.stringify(draft))
    
    showAutoSaveIndicator.value = true
    setTimeout(() => {
      showAutoSaveIndicator.value = false
    }, 2000)
  } catch (error) {
    console.error('Error guardando borrador:', error)
  }
}

const loadDraft = () => {
  try {
    const draft = localStorage.getItem('listing_draft')
    if (draft) {
      const parsed = JSON.parse(draft)
      
      const savedAt = new Date(parsed.savedAt)
      const now = new Date()
      const daysDiff = (now - savedAt) / (1000 * 60 * 60 * 24)
      
      if (daysDiff < 7) {
        formData.value = { ...formData.value, ...parsed }
        console.log('Borrador cargado desde localStorage')
      } else {
        localStorage.removeItem('listing_draft')
      }
    }
  } catch (error) {
    console.error('Error cargando borrador:', error)
  }
}

// ==========================================
// SUBMIT (PUBLICAR ANUNCIO)
// ==========================================

const submitForm = async () => {
  isSubmitting.value = true
  
  try {
    const payload = new FormData()
    
    // Datos básicos
    payload.append('category', formData.value.category)
    payload.append('subcategory', formData.value.subcategory)
    payload.append('city', formData.value.city)
    payload.append('address', formData.value.address)
    payload.append('title', formData.value.title)
    payload.append('description', formData.value.description)
    payload.append('whatsapp', formData.value.whatsapp)
    payload.append('plan', formData.value.plan)
    
    // Campos opcionales comunes
    if (formData.value.price) {
      payload.append('price', formData.value.price)
    }
    if (formData.value.email) {
      payload.append('email', formData.value.email)
    }
    if (formData.value.website) {
      payload.append('website', formData.value.website)
    }
    
    // Campos específicos según categoría
    if (formData.value.category === 'gastronomia') {
      if (formData.value.priceRange) {
        payload.append('price_range', formData.value.priceRange)
      }
      payload.append('delivery_available', formData.value.deliveryAvailable)
      if (formData.value.capacity) {
        payload.append('capacity', formData.value.capacity)
      }
      payload.append('parking', formData.value.parking)
      if (formData.value.schedule) {
        payload.append('schedule', formData.value.schedule)
      }
      if (formData.value.features && formData.value.features.length > 0) {
        payload.append('features', JSON.stringify(formData.value.features))
      }
      
      // Menú (array de platos)
      if (formData.value.menuItems && formData.value.menuItems.length > 0) {
        payload.append('menu_items', JSON.stringify(formData.value.menuItems))
        
        // Imágenes de platos
        formData.value.menuItems.forEach((item, index) => {
          if (item.image instanceof File) {
            payload.append(`menu_image_${index}`, item.image)
          }
        })
      }
    } else if (formData.value.category === 'profesionales') {
      // Campos profesionales
      if (formData.value.professionalTitle) {
        payload.append('professional_title', formData.value.professionalTitle)
      }
      if (formData.value.yearsExperience) {
        payload.append('years_experience', formData.value.yearsExperience)
      }
      // ... más campos profesionales
    }
    
    // Imágenes del negocio/logo
    formData.value.images.forEach((img, index) => {
      if (img.file) {
        payload.append(`images`, img.file)
        if (index === 0) {
          payload.append('main_image_index', '0')
        }
      }
    })
    
    // TODO Django: Descomentar cuando tengamos backend
    // const response = await axios.post('/api/listings/', payload, {
    //   headers: { 'Content-Type': 'multipart/form-data' }
    // })
    
    // Simulación
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    console.log('Formulario enviado:', formData.value)
    
    localStorage.removeItem('listing_draft')
    
    if (formData.value.plan !== 'free') {
      alert(`Redirigiendo a pasarela de pago - Plan: ${formData.value.plan}`)
      router.push('/')
    } else {
      alert('¡Anuncio publicado exitosamente!')
      router.push('/')
    }
    
  } catch (error) {
    console.error('Error al publicar anuncio:', error)
    alert('Error al publicar. Inténtalo de nuevo.')
  } finally {
    isSubmitting.value = false
  }
}

// ==========================================
// WATCHERS
// ==========================================

let autoSaveTimeout = null
watch(formData, () => {
  clearTimeout(autoSaveTimeout)
  autoSaveTimeout = setTimeout(() => {
    saveAsDraft()
  }, 3000)
}, { deep: true })

// ==========================================
// LIFECYCLE HOOKS
// ==========================================

onMounted(() => {
  loadDraft()
  scrollToTop()
})
</script>

<style scoped>
/* [ESTILOS IGUALES QUE ANTES] */

.publish-section {
  min-height: calc(100vh - 200px);
  padding: 3rem 1rem;
  background: linear-gradient(135deg, #FAFAFA 0%, #FFFFFF 100%);
}

.container {
  max-width: 900px;
  margin: 0 auto;
}

.publish-header {
  text-align: center;
  margin-bottom: 3rem;
}

.publish-title {
  font-size: 2.5rem;
  font-weight: 800;
  color: var(--color-purple-darkest);
  margin-bottom: 0.5rem;
}

.publish-subtitle {
  font-size: 1.125rem;
  color: #666;
  line-height: 1.5;
}

.form-card {
  background: white;
  border-radius: 16px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  padding: 2.5rem;
  margin-bottom: 2rem;
}

.summary-step {
  padding: 0;
}

.form-navigation {
  display: flex;
  gap: 1rem;
  padding-top: 2rem;
  margin-top: 2rem;
  border-top: 2px solid #E0E0E0;
}

.spacer {
  flex: 1;
}

.nav-btn {
  min-width: 140px;
  font-weight: 600;
  transition: all 0.3s ease;
}

.nav-btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
}

.submit-btn {
  box-shadow: 0 4px 12px rgba(253, 197, 0, 0.3);
}

.submit-btn:hover {
  box-shadow: 0 6px 20px rgba(253, 197, 0, 0.5);
}

.auto-save-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 1rem;
  background: #E8F5E9;
  border-radius: 12px;
  color: #2E7D32;
  font-weight: 600;
  animation: fadeInUp 0.3s ease;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .publish-section {
    padding: 2rem 1rem;
  }

  .publish-title {
    font-size: 2rem;
  }

  .publish-subtitle {
    font-size: 1rem;
  }

  .form-card {
    padding: 1.5rem;
  }

  .form-navigation {
    flex-direction: column;
  }

  .nav-btn {
    width: 100%;
    min-width: auto;
  }

  .spacer {
    display: none;
  }
}

@media (max-width: 480px) {
  .publish-section {
    padding: 1.5rem 0.75rem;
  }

  .publish-header {
    margin-bottom: 2rem;
  }

  .publish-title {
    font-size: 1.75rem;
  }

  .form-card {
    padding: 1rem;
    border-radius: 12px;
  }
}
</style>