<!-- frontend/src/components/Auth/AuthModal.vue -->
<template>
  <VaModal
    v-model="isOpen"
    size="small"
    :hide-default-actions="true"
    @update:model-value="handleClose"
  >
    <template #header>
      <h2 class="modal-title">
        <va-icon :name="currentTab === 'login' ? 'login' : 'person_add'" color="purple" />
        {{ currentTab === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta' }}
      </h2>
    </template>

    <!-- Tabs -->
    <div class="auth-tabs">
      <button
        :class="['tab-btn', { active: currentTab === 'login' }]"
        @click="currentTab = 'login'"
      >
        Iniciar Sesión
      </button>
      <button
        :class="['tab-btn', { active: currentTab === 'register' }]"
        @click="currentTab = 'register'"
      >
        Registrarse
      </button>
    </div>

    <!-- LOGIN FORM -->
    <form v-if="currentTab === 'login'" @submit.prevent="handleLogin" class="auth-form">
      <VaInput
        v-model="loginForm.email"
        type="email"
        label="Email"
        placeholder="tu@email.com"
        :rules="[(v) => !!v || 'Email es requerido']"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="email" />
        </template>
      </VaInput>

      <VaInput
        v-model="loginForm.password"
        :type="showPassword ? 'text' : 'password'"
        label="Contraseña"
        placeholder="Tu contraseña"
        :rules="[(v) => !!v || 'Contraseña es requerida']"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="lock" />
        </template>
        <template #append>
          <va-icon
            :name="showPassword ? 'visibility_off' : 'visibility'"
            @click="showPassword = !showPassword"
            style="cursor: pointer;"
          />
        </template>
      </VaInput>

      <div class="form-actions">
        <VaButton type="submit" color="purple" :loading="authStore.isLoading" block>
          Iniciar Sesión
        </VaButton>
      </div>

      <div class="form-footer">
        <a href="#" class="forgot-password">¿Olvidaste tu contraseña?</a>
      </div>
    </form>

    <!-- REGISTER FORM -->
    <form v-if="currentTab === 'register'" @submit.prevent="handleRegister" class="auth-form">
      <VaInput
        v-model="registerForm.name"
        label="Nombre Completo"
        placeholder="Juan Pérez"
        :rules="[(v) => !!v || 'Nombre es requerido']"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="person" />
        </template>
      </VaInput>

      <VaInput
        v-model="registerForm.email"
        type="email"
        label="Email"
        placeholder="tu@email.com"
        :rules="[
          (v) => !!v || 'Email es requerido',
          (v) => /.+@.+\..+/.test(v) || 'Email debe ser válido'
        ]"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="email" />
        </template>
      </VaInput>

      <VaInput
        v-model="registerForm.phone"
        type="tel"
        label="Teléfono (Opcional)"
        placeholder="+591 70123456"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="phone" />
        </template>
      </VaInput>

      <VaInput
        v-model="registerForm.password"
        :type="showPassword ? 'text' : 'password'"
        label="Contraseña"
        placeholder="Mínimo 6 caracteres"
        :rules="[
          (v) => !!v || 'Contraseña es requerida',
          (v) => v.length >= 6 || 'Mínimo 6 caracteres'
        ]"
        class="form-field"
      >
        <template #prepend>
          <va-icon name="lock" />
        </template>
        <template #append>
          <va-icon
            :name="showPassword ? 'visibility_off' : 'visibility'"
            @click="showPassword = !showPassword"
            style="cursor: pointer;"
          />
        </template>
      </VaInput>

      <div class="form-actions">
        <VaButton type="submit" color="purple" :loading="authStore.isLoading" block>
          Crear Cuenta
        </VaButton>
      </div>

      <div class="form-footer">
        <p class="terms-text">
          Al registrarte, aceptas nuestros 
          <a href="#">Términos y Condiciones</a>
        </p>
      </div>
    </form>
  </VaModal>
</template>

<script setup>
import { ref } from 'vue'
import { useAuthStore } from '@/stores/useAuthStore'
import { useToast } from 'vuestic-ui'

// ========== STORES & COMPOSABLES ==========
const authStore = useAuthStore()
const { init: notify } = useToast()

// ========== PROPS & EMITS ==========
const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['update:modelValue', 'success'])

// ========== STATE ==========
const isOpen = ref(props.modelValue)
const currentTab = ref('login')
const showPassword = ref(false)

const loginForm = ref({
  email: '',
  password: ''
})

const registerForm = ref({
  name: '',
  email: '',
  phone: '',
  password: ''
})

// ========== METHODS ==========
const handleClose = (value) => {
  isOpen.value = value
  emit('update:modelValue', value)
  
  // Reset forms
  if (!value) {
    resetForms()
  }
}

const resetForms = () => {
  loginForm.value = { email: '', password: '' }
  registerForm.value = { name: '', email: '', phone: '', password: '' }
  showPassword.value = false
}

const handleLogin = async () => {
  const result = await authStore.login(loginForm.value.email, loginForm.value.password)
  
  if (result.success) {
    notify({
      message: '¡Bienvenido de nuevo!',
      color: 'success'
    })
    handleClose(false)
    emit('success')
  } else {
    notify({
      message: result.error || 'Error al iniciar sesión',
      color: 'danger'
    })
  }
}

const handleRegister = async () => {
  const result = await authStore.register(
    registerForm.value.name,
    registerForm.value.email,
    registerForm.value.password,
    registerForm.value.phone
  )
  
  if (result.success) {
    notify({
      message: '¡Cuenta creada exitosamente!',
      color: 'success'
    })
    handleClose(false)
    emit('success')
  } else {
    notify({
      message: result.error || 'Error al registrarse',
      color: 'danger'
    })
  }
}

// Watch prop changes
import { watch } from 'vue'
watch(() => props.modelValue, (newValue) => {
  isOpen.value = newValue
})
</script>

<style scoped>
.modal-title {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 1.5rem;
  font-weight: 700;
  color: var(--color-purple-darkest);
  margin: 0;
}

/* ========== TABS ========== */
.auth-tabs {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.5rem;
  margin-bottom: 2rem;
  padding: 0.5rem;
  background: #F5F5F5;
  border-radius: 12px;
}

.tab-btn {
  padding: 0.75rem 1rem;
  background: transparent;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  color: #666;
  cursor: pointer;
  transition: all 0.3s ease;
}

.tab-btn:hover {
  background: rgba(92, 0, 153, 0.1);
  color: var(--color-purple);
}

.tab-btn.active {
  background: white;
  color: var(--color-purple);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* ========== FORM ========== */
.auth-form {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

.form-field {
  width: 100%;
}

.form-actions {
  margin-top: 0.5rem;
}

.form-footer {
  text-align: center;
  padding-top: 0.5rem;
}

.forgot-password {
  color: var(--color-purple);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
}

.forgot-password:hover {
  text-decoration: underline;
}

.terms-text {
  font-size: 0.85rem;
  color: #666;
  margin: 0;
}

.terms-text a {
  color: var(--color-purple);
  text-decoration: none;
}

.terms-text a:hover {
  text-decoration: underline;
}
</style>